Android Camera Utilities
========================

This Android Library contains a collection of utilities used across different
samples in this repo, it is not intended to be run as a standalone application.